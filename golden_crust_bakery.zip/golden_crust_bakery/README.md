# Golden Crust Bakery — Sistem Informasi Toko Bakery

Proyek frontend untuk tugas kuliah Vibe Coding Web. Tema: bakery premium dengan warna butter yellow, cream, putih, dan cokelat.

## Isi folder
- `index.html` — struktur halaman website
- `style.css` — desain responsif
- `app.js` — katalog, keranjang, checkout, login demo admin, CRUD produk, status pesanan, dan laporan

## Cara menjalankan di VS Code
1. Ekstrak ZIP ini ke folder yang mudah ditemukan.
2. Buka VS Code → **File → Open Folder** → pilih folder `golden_crust_bakery`.
3. Buka `index.html`.
4. Cara paling mudah: klik kanan `index.html` lalu pilih **Open with Live Server** (jika ekstensi Live Server sudah terpasang).
5. Jika tidak memakai Live Server, buka `index.html` langsung di browser. Koneksi internet diperlukan untuk font dan foto online.

## Login demo admin
- Email: `admin@goldencrust.test`
- Password: `bakery123`
- Klik tombol **Mode Admin** pada header toko.

## Fitur
- Landing page dan katalog 12 produk bakery
- Pencarian, filter kategori, dan pengurutan produk
- Keranjang belanja dengan ubah jumlah dan hapus item
- Checkout, kode promo `GOLDEN20`, dan riwayat pesanan
- Dashboard admin
- CRUD produk (tambah, edit, hapus)
- Manajemen status pesanan
- Ringkasan dan cetak laporan penjualan

## Catatan penting
Versi ini adalah **prototipe frontend**. Data disimpan di `localStorage` browser, bukan database server. Login admin hanya simulasi dan tidak aman untuk penggunaan produksi. Pembayaran tidak diproses sungguhan. Untuk sistem nyata, tambahkan backend (misalnya PHP) dan database (MySQL), validasi server, serta autentikasi yang aman.

Foto produk dimuat dari Unsplash sehingga membutuhkan koneksi internet. Jika gambar tidak tersedia, website menggunakan gambar cadangan.
